The weights are stored with git's Large File Storage (https://git-lfs.github.com/).

In order to use these weights, first clone the repository and then run `git lfs pull`

```
git clone https://github.com/idealo/image-super-resolution
cd image-super-resolution
git lfs pull
```
