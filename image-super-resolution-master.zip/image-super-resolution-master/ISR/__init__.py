from . import assistant

__version__ = '2.0.5'
